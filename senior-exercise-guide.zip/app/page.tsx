import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { ArrowRight, Award, Calendar, Heart, Users } from "lucide-react"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-[#120d1a] to-[#1a1625]">
      {/* Hero Section */}
      <section className="container mx-auto px-4 pt-16 pb-20 text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-purple-400 mb-6">Exercícios para Todas as Idades</h1>
        <p className="text-xl text-purple-100 max-w-3xl mx-auto mb-10">
          Uma plataforma simples e completa para ajudar pessoas de todas as idades a se manterem ativas e saudáveis com
          exercícios adaptados para cada faixa etária.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/cadastro">
            <Button size="lg" className="text-lg px-8 bg-purple-600 hover:bg-purple-700">
              Começar Agora <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
          <Link href="/login">
            <Button
              size="lg"
              variant="outline"
              className="text-lg px-8 border-purple-500 text-purple-400 hover:bg-purple-900"
            >
              Já tenho uma conta
            </Button>
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16 bg-[#231c34] rounded-t-3xl">
        <h2 className="text-3xl font-bold text-center text-purple-400 mb-12">Por que usar nossa plataforma?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <Card className="border-2 border-purple-800">
            <CardContent className="pt-6">
              <div className="rounded-full bg-purple-900 w-14 h-14 flex items-center justify-center mb-4 mx-auto">
                <Heart className="h-7 w-7 text-purple-400" />
              </div>
              <h3 className="text-xl font-semibold text-center mb-2 text-purple-300">Exercícios Adaptados</h3>
              <p className="text-purple-200 text-center">
                Todos os exercícios são adaptados para diferentes faixas etárias e níveis de condicionamento.
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 border-purple-800">
            <CardContent className="pt-6">
              <div className="rounded-full bg-purple-900 w-14 h-14 flex items-center justify-center mb-4 mx-auto">
                <Calendar className="h-7 w-7 text-purple-400" />
              </div>
              <h3 className="text-xl font-semibold text-center mb-2 text-purple-300">Progresso Semanal</h3>
              <p className="text-purple-200 text-center">
                Os treinos mudam a cada semana, garantindo evolução constante e evitando a monotonia.
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 border-purple-800">
            <CardContent className="pt-6">
              <div className="rounded-full bg-purple-900 w-14 h-14 flex items-center justify-center mb-4 mx-auto">
                <Users className="h-7 w-7 text-purple-400" />
              </div>
              <h3 className="text-xl font-semibold text-center mb-2 text-purple-300">Fácil de Usar</h3>
              <p className="text-purple-200 text-center">
                Interface simples e intuitiva, pensada especialmente para quem não tem familiaridade com tecnologia.
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 border-purple-800">
            <CardContent className="pt-6">
              <div className="rounded-full bg-purple-900 w-14 h-14 flex items-center justify-center mb-4 mx-auto">
                <Award className="h-7 w-7 text-purple-400" />
              </div>
              <h3 className="text-xl font-semibold text-center mb-2 text-purple-300">Acompanhamento</h3>
              <p className="text-purple-200 text-center">
                Acompanhe seu progresso, marque exercícios concluídos e veja sua evolução ao longo do tempo.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-3xl font-bold text-purple-400 mb-6">Comece sua jornada para uma vida mais ativa</h2>
        <p className="text-xl text-purple-200 max-w-3xl mx-auto mb-10">
          Cadastre-se gratuitamente e tenha acesso a todos os exercícios e recursos da plataforma.
        </p>
        <Link href="/cadastro">
          <Button size="lg" className="text-lg px-8 bg-purple-600 hover:bg-purple-700">
            Criar Conta Gratuita
          </Button>
        </Link>
      </section>

      {/* Footer */}
      <footer className="bg-[#120d1a] py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-purple-300">© 2025 Exercícios para Idosos. Todos os direitos reservados.</p>
          <div className="flex justify-center gap-6 mt-4">
            <Link href="/sobre" className="text-purple-400 hover:text-purple-300">
              Sobre Nós
            </Link>
            <Link href="/contato" className="text-purple-400 hover:text-purple-300">
              Contato
            </Link>
            <Link href="/termos" className="text-purple-400 hover:text-purple-300">
              Termos de Uso
            </Link>
            <Link href="/privacidade" className="text-purple-400 hover:text-purple-300">
              Privacidade
            </Link>
          </div>
        </div>
      </footer>
    </main>
  )
}
